// DO DOKO�CZENIA

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int a, b, c;
    //int tab[3];
    double tab2[4];
    double x1;
    double x2;
    double delta;


    cout << "a: ";
    cin >> a;
    cout << "b: ";
    cin >> b;
    cout << "c: ";
    cin >> c;

    /* if(delta > 0){
        x1 = (- b - sqrt(delta))/(2*a);
        x2 = (- b + sqrt(delta))/(2*a);
    } else if(delta == 0){
        x1 = -b/(2*a)
    } */


    delta = b*b - 4*a*c;

    if (delta > 0) {

        x1 = (-b + sqrt(delta)) / (2*a);
        x2 = (-b - sqrt(delta)) / (2*a);

        cout << "X sa liczbami rzeczywistymi i sa rozne." << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;
    }

    else if (delta == 0) {
        /*if(a == 0 && b != 0){
            cout <<
        }*/

        cout << "X sa w liczbami rzeczywistymi i sa takie same." << endl;
        x1 = -b/(2*a);
        cout << "x1 = x2 = " << x1 << endl;
    }

    else {


        double realPart = -b/(2*a);
        double imaginaryPart =sqrt(-delta)/(2*a);
        cout << "X sa liczbami zespolonymi i sa rozne."  << endl;
        cout << "x1 = " << realPart << "+" << imaginaryPart << "i" << endl;
        cout << "x2 = " << realPart << "-" << imaginaryPart << "i" << endl;
    }




    /* switch(tab[0]){
    case (tab[0] != 0 && delta > 0)
        cout << delta << endl; */


    return 0;
}
